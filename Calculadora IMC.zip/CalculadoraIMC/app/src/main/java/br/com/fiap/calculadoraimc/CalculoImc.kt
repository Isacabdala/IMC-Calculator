package br.com.fiap.calculadoraimc

import kotlin.math.pow

fun calcularImc(pesoUsuario:Double, alturaUsuario: Double): Double {
    var  imc = pesoUsuario/(alturaUsuario/ 100).pow(2)
    return imc
}


fun determinarClassificacaoIMC(imcUuario: Double): String {
    return if(imcUuario < 18.5) {
        "Abaixo do peso"
    } else if (imcUuario >= 18.5 && imcUuario < 25.0) {
        "Peso Ideal"
    } else if (imcUuario >= 25.0 && imcUuario < 30.0) {
        "Levemente acima do peso"
    } else if (imcUuario >= 30.0 && imcUuario < 35.0) {
        "Obesidade Grau I"
    } else if (imcUuario >= 35.0 && imcUuario < 40.0) {
        "Obesidade Grau II"
    } else {"Obesidade Grau III"}
}
